local ACHIEVEMENT_ID = 4815 -- The Twilight Destroyer (25 player)

local f = CreateFrame("Frame")

local function OnAchievementReady()
    local _, name, _, completed = GetAchievementComparisonInfo(ACHIEVEMENT_ID)
    if name ~= nil then
        if completed then
            print("|cff00ff00[AchievementChecker]|r Target has the achievement: |cff00ff00OK|r")
        else
            print("|cffff0000[AchievementChecker]|r Target doesn't have the achievement: |cffff0000NO|r")
        end
    else
        print("|cffff0000[AchievementChecker]|r Target doesn't have the achievement: |cffff0000NO|r")
    end
    ClearAchievementComparisonUnit()
    f:UnregisterEvent("INSPECT_ACHIEVEMENT_READY")
end

SLASH_ACHCHECK1 = "/achcheck"
SlashCmdList["ACHCHECK"] = function()
    if not UnitExists("target") then
        print("|cffff8800[AchievementChecker]|r No target selected.")
        return
    end
    SetAchievementComparisonUnit("target")
    f:RegisterEvent("INSPECT_ACHIEVEMENT_READY")
end

f:SetScript("OnEvent", function(self, event, ...)
    if event == "INSPECT_ACHIEVEMENT_READY" then
        OnAchievementReady()
    end
end)
