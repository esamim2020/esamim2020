AchievementChecker Addon for WoW 3.3.5a
=======================================

This addon checks if your current target has completed a specific achievement:  
**The Twilight Destroyer (25 player)** (Achievement ID: 4815).

Features
--------

- Quickly check if your target has the achievement.
- Shows a clear green "OK" if the target has it.
- Shows a red "NO" if the target does not have it.
- Easy-to-use slash command.

How to Use
----------

1. Target a player character you want to inspect.
2. Make sure you are within inspect range.
3. Type the following command in chat:

   /achcheck

Output Example
--------------

After running the command, you will see one of the following messages:

- If the target has the achievement:

  [AchievementChecker] Target has the achievement: OK

- If the target does not have the achievement or data is not available:

  [AchievementChecker] Target doesn't have the achievement: NO

Notes
-----

- You must have a target selected and be close enough to inspect.
- If no target is selected, you will be notified.
- The addon waits until the achievement data is loaded before printing the result.

Installation
------------

1. Place the addon Lua file (e.g., `AchievementChecker.lua`) in a folder inside your WoW 3.3.5a Interface/AddOns directory.
2. Reload your UI with `/reload` or restart the game.
3. Use `/achcheck` in chat while targeting a player to check their achievement status.

---

If you want help creating the `.toc` file or want to customize this addon further, just let me know!
