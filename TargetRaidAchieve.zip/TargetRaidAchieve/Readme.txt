TargetRaidAchieve Addon for WoW 3.3.5a
======================================

This addon allows you to inspect the raid achievement progress of your current target for three major Wrath of the Lich King raids: Icecrown Citadel (ICC), Ruby Sanctum (RS), and Trial of the Crusader (TOC). It displays whether the target has completed the main raid achievements in Normal and Heroic modes for 10 and 25-man versions.

Features
--------

- Check target's raid achievements quickly via slash commands.
- Displays colored, easy-to-read output in chat:
  - Green "Done" if achievement completed.
  - Red "Not Done" if achievement not completed.
- Shows the target's class and race in their class color for context.
- Supports the main raid achievements for ICC, RS, and TOC.

Supported Raid Achievement Categories
-------------------------------------

| Raid Code | Raid Name              | Achievement Examples                       |
|-----------|------------------------|-------------------------------------------|
| icc       | Icecrown Citadel       | Fall of the Lich King (10N, 10HC, 25N, 25HC) |
| rs        | Ruby Sanctum           | The Twilight Destroyer (10N, 10HC, 25N, 25HC) |
| toc       | Trial of the Crusader  | Trial of the Crusader (10N, 10HC, 25N, 25HC)  |

How to Use
----------

1. Target a player character you want to inspect.
2. Make sure you are within inspect range.
3. Type one of the following slash commands in chat:

   /achh icc
   /achh rs
   /achh toc

- Replace `icc`, `rs`, or `toc` with the raid you want to check.
- For example, to check ICC achievements on your target, use `/achh icc`.

Output Example
--------------

After running the command, you will see output like:

ICC ACHIEVEMENTS for: Thrall (Orc Shaman)
Fall of the Lich King / ICC 10N: Done
Fall of the Lich King / ICC 10HC: Not Done
Fall of the Lich King / ICC 25N: Done
Fall of the Lich King / ICC 25HC: Not Done

- "Done" is shown in green.
- "Not Done" is shown in red.
- The target's name and class/race info appear in their class color.

Notes
-----

- You must have a target selected and be close enough to inspect them.
- If no valid target or out of range, you'll get a warning message.
- Achievements update only after the game client finishes retrieving achievement data from the target (may take a second).

Installation
------------

1. Place `TargetRaidAchieve.lua` in a folder inside your WoW 3.3.5a Interface/AddOns directory.
2. Reload your UI with `/reload` or restart the game.
3. Use the slash commands as described above.

---

If you want me to help create the `.toc` file or package the addon, just let me know!
