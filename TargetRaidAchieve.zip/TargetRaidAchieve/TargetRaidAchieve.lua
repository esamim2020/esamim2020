local f = CreateFrame("Frame")
local raidAchievements = {
    icc = {
        ["Fall of the Lich King / ICC 10N"] = 4532,
        ["Fall of the Lich King / ICC 10HC"] = 4636,
        ["Fall of the Lich King / ICC 25N"] = 4608,
        ["Fall of the Lich King / ICC 25HC"] = 4637,
    },
    rs = {
        ["The Twilight Destroyer (10 Normal)"] = 4817,
        ["The Twilight Destroyer (10 Heroic)"] = 4818,
        ["The Twilight Destroyer (25 Heroic)"] = 4816,
        ["The Twilight Destroyer (25 Normal)"] = 4815,
    },
    toc = {
        ["Trial of the Crusader / 10N"] = 3917,
        ["Trial of the Crusader / 10HC"] = 3918,
        ["Trial of the Crusader / 25N"] = 3916,
        ["Trial of the Crusader / 25HC"] = 3812,
    },
}

local raidColors = {
    icc = "|cff66ccff",
    rs  = "|cffff6600",
    toc = "|cffbbbbbb",
}

local currentRaid = nil
local targetName = ""

-- Helper: apply color to text
local function colored(text, hex)
    return hex .. text .. "|r"
end

-- Helper: get colored class name + race
local function GetColoredTargetInfo(unit)
    local className, classFilename = UnitClass(unit)
    local race = UnitRace(unit) or "Unknown"
    local name = UnitName(unit) or "Unknown"
    local color = RAID_CLASS_COLORS[classFilename]
    if color then
        local fullText = string.format("%s (%s %s)", name, race, className)
        return string.format("|cff%02x%02x%02x%s|r", color.r * 255, color.g * 255, color.b * 255, fullText)
    else
        return string.format("%s (%s %s)", name, race, className)
    end
end

local function PrintAchievements(achTable, raidKey)
    local titleColor = "|cffffff00" -- زرد
    local targetInfo = GetColoredTargetInfo("target")
    print(titleColor .. raidKey:upper() .. " Achievements for:|r " .. targetInfo)

    local textColor = raidColors[raidKey] or "|cffffff00"

    for name, id in pairs(achTable) do
        local _, _, _, completed = GetAchievementComparisonInfo(id)
        local status = completed and colored("Done", "|cff00ff00") or colored("Not Done", "|cffff0000")
        print(textColor .. name .. ":|r " .. status)
    end
end

f:SetScript("OnEvent", function(_, event)
    if event == "INSPECT_ACHIEVEMENT_READY" then
        PrintAchievements(raidAchievements[currentRaid], currentRaid)
        ClearAchievementComparisonUnit()
        f:UnregisterEvent("INSPECT_ACHIEVEMENT_READY")
        currentRaid = nil
    end
end)

-- Helper trim
function string.trim(s)
    return s:match("^%s*(.-)%s*$")
end

SLASH_ACHH1 = "/achh"
SlashCmdList["ACHH"] = function(msg)
    msg = string.lower(string.trim(msg))
    if not raidAchievements[msg] then
        print("|cffff0000Usage: /achh <icc|rs|toc>|r")
        return
    end

    if UnitExists("target") and CanInspect("target") then
        targetName = UnitName("target")
        currentRaid = msg
        f:RegisterEvent("INSPECT_ACHIEVEMENT_READY")
        SetAchievementComparisonUnit("target")
    else
        print("|cffff0000You must target a player first and be in inspect range.|r")
    end
end
