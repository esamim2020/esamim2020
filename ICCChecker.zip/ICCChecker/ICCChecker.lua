-- ICC raid wing achievements by mode (no links)
local ICC_WING_ACHIEVEMENTS = {
    [1] = {
        modeName = "10 Normal (10N)",
        wings = {
            { id = 4531, name = "Storming the Citadel (10N)" },
            { id = 4528, name = "The Plagueworks (10N)" },
            { id = 4529, name = "The Crimson Hall (10N)" },
            { id = 4527, name = "The Frostwing Halls (10N)" },
            { id = 4530, name = "The Frozen Throne (10N)" },
        }
    },
    [2] = {
        modeName = "10 Heroic (10HC)",
        wings = {
            { id = 4628, name = "Storming the Citadel (10HC)" },
            { id = 4629, name = "The Plagueworks (10HC)" },
            { id = 4630, name = "The Crimson Hall (10HC)" },
            { id = 4631, name = "The Frostwing Halls (10HC)" },
            { id = 4583, name = "The Frozen Throne (10HC)" },
        }
    },
    [3] = {
        modeName = "25 Normal (25N)",
        wings = {
            { id = 4604, name = "Storming the Citadel (25N)" },
            { id = 4605, name = "The Plagueworks (25N)" },
            { id = 4606, name = "The Crimson Hall (25N)" },
            { id = 4607, name = "The Frostwing Halls (25N)" },
            { id = 4597, name = "The Frozen Throne (25N)" },
        }
    },
    [4] = {
        modeName = "25 Heroic (25HC)",
        wings = {
            { id = 4632, name = "Storming the Citadel (25HC)" },
            { id = 4633, name = "The Plagueworks (25HC)" },
            { id = 4634, name = "The Crimson Hall (25HC)" },
            { id = 4635, name = "The Frostwing Halls (25HC)" },
            { id = 4584, name = "The Frozen Throne (25HC)" },
        }
    },
}

local RAID_CLASS_COLORS = CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
local f = CreateFrame("Frame")
local currentMode = nil

local function TitleCaseClassName(class)
    local map = {
        DEATHKNIGHT = "Death Knight", DRUID = "Druid", HUNTER = "Hunter",
        MAGE = "Mage", PALADIN = "Paladin", PRIEST = "Priest",
        ROGUE = "Rogue", SHAMAN = "Shaman", WARLOCK = "Warlock", WARRIOR = "Warrior"
    }
    return map[class] or class
end

local function GetClassColorHex(class)
    local color = RAID_CLASS_COLORS[class] or { r = 1, g = 1, b = 1 }
    return string.format("|cff%02x%02x%02x", color.r * 255, color.g * 255, color.b * 255)
end

local function GetColoredPlayerLine(unit)
    if not UnitExists(unit) then return "|cffffffffUnknown|r" end
    local name = UnitName(unit) or "Unknown"
    local race = UnitRace(unit) or "Unknown"
    local _, classFile = UnitClass(unit)
    local className = TitleCaseClassName(classFile)
    local colorHex = GetClassColorHex(classFile)
    return string.format("%s%s %s %s|r", colorHex, name, race, className)
end

local function CheckICCStats()
    local data = ICC_WING_ACHIEVEMENTS[currentMode]
    if not data then
        print("|cffff0000[ICCChecker]|r Invalid ICC mode.")
        return
    end

    print("|cffffff00[ICCChecker]|r |cffffff00ICC Achievement Checker Start Checking|r")
    print(string.format("|cff00ffff[ICCChecker]|r Checking ICC %s for:", data.modeName))
    print(GetColoredPlayerLine("target"))

    for _, wing in ipairs(data.wings) do
        local id = wing.id
        local completed = select(4, GetAchievementComparisonInfo(id)) -- true if completed
        local colorCode = completed and "|cff00ff00" or "|cffff0000"
        local status = completed and "Done" or "Not Done"
        print(string.format("%s%s: %s|r", colorCode, wing.name, status))
    end

    print("|cff888888________________________________________|r\n")
    ClearAchievementComparisonUnit()
    f:UnregisterEvent("INSPECT_ACHIEVEMENT_READY")
end

SLASH_ICCCHECK1 = "/icc"
SlashCmdList["ICCCHECK"] = function(arg)
    local mode = tonumber(arg)
    if not mode or mode < 1 or mode > 4 then
        print("|cffff8800[ICCChecker]|r Usage: /icc 1 - 4 (1=10N, 2=10HC, 3=25N, 4=25HC)")
        return
    end

    if not UnitExists("target") then
        print("|cffff8800[ICCChecker]|r No target selected.")
        return
    end

    currentMode = mode
    SetAchievementComparisonUnit("target")
    f:RegisterEvent("INSPECT_ACHIEVEMENT_READY")
end

f:SetScript("OnEvent", function(_, event)
    if event == "INSPECT_ACHIEVEMENT_READY" then
        CheckICCStats()
    end
end)
