ICCChecker Addon for WoW 3.3.5a
===============================

This addon allows you to inspect the individual wing achievements of the Icecrown Citadel (ICC) raid for your current target. It checks completion status for each wing in all four raid modes: 10 Normal, 10 Heroic, 25 Normal, and 25 Heroic.

Features
--------

- Check wing-by-wing ICC raid achievements for your target.
- Shows "Done" or "Not Done" for each wing in colored text (green/red).
- Displays target’s name, race, and class with class-colored text for clarity.
- Easy to use slash command with mode selection.

Supported ICC Modes
-------------------

| Mode Number | Mode Name         | Description            |
|-------------|-------------------|------------------------|
| 1           | 10 Normal (10N)   | Normal 10-man ICC wings|
| 2           | 10 Heroic (10HC)  | Heroic 10-man ICC wings|
| 3           | 25 Normal (25N)   | Normal 25-man ICC wings|
| 4           | 25 Heroic (25HC)  | Heroic 25-man ICC wings|

How to Use
----------

1. Target a player character you want to inspect.
2. Make sure you are within inspect range.
3. Use the slash command with the mode number in chat:

   /icc 1  -- Checks ICC 10 Normal wings
   /icc 2  -- Checks ICC 10 Heroic wings
   /icc 3  -- Checks ICC 25 Normal wings
   /icc 4  -- Checks ICC 25 Heroic wings

Output Example
--------------

After running the command, you will see output like:

[ICCChecker] ICC Achievement Checker Start Checking
[ICCChecker] Checking ICC 10 Normal (10N) for:
Thrall Orc Shaman

Storming the Citadel (10N): Done
The Plagueworks (10N): Not Done
The Crimson Hall (10N): Done
The Frostwing Halls (10N): Done
The Frozen Throne (10N): Not Done

________________________________________

- "Done" is green.
- "Not Done" is red.
- Target’s info is shown in class color for better readability.

Notes
-----

- You must have a target selected and be close enough to inspect.
- If no target or invalid mode, the addon will print usage instructions or warnings.
- The achievement data is updated after the inspection finishes (may take a moment).

Installation
------------

1. Place `ICCChecker.lua` in a folder inside your WoW 3.3.5a Interface/AddOns directory.
2. Reload your UI with `/reload` or restart the game.
3. Use the slash commands as described above.

---

If you want help creating the `.toc` file or packaging the addon, just ask!
