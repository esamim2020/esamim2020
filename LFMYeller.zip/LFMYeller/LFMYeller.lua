local frame = CreateFrame("Frame")

print("|cffFF69B4[Yeller]|r Addon loaded successfully!")

local isYelling = false
local isChanneling = false

local yellMessage = "LFM Raid :))"
local chanMessage = "LFM Channel Message :))"

local yellInterval = 20
local chanInterval = 20

local yellElapsed = 0
local chanElapsed = 0

local chanName = nil
local chanID = nil

local function printMsg(msg)
    print("|cffFF69B4[Yeller]|r " .. msg)
end

local function GetJoinedChannelID(channel)
    if not channel or channel == "" then return nil end
    local id = GetChannelName(channel)
    if id ~= 0 then
        return id
    end
    return nil
end

local function StartYelling()
    if not isYelling then
        isYelling = true
        yellElapsed = yellInterval -- yell immediately on start
        printMsg("Yell started.")
    else
        printMsg("Yell already started.")
    end
end

local function StopYelling()
    if isYelling then
        isYelling = false
        printMsg("Yell stopped.")
    else
        printMsg("Yell is not running.")
    end
end

local function StartChanneling()
    if not chanName then
        printMsg("Error: No channel set. Use /yeller channel <channel> first.")
        return
    end
    if not isChanneling then
        isChanneling = true
        chanElapsed = chanInterval -- immediate send
        printMsg("Channel messages started on channel '" .. chanName .. "'.")
    else
        printMsg("Channel messages already started.")
    end
end

local function StopChanneling()
    if isChanneling then
        isChanneling = false
        printMsg("Channel messages stopped.")
    else
        printMsg("Channel messages are not running.")
    end
end

frame:SetScript("OnUpdate", function(self, elapsed)
    if isYelling then
        yellElapsed = yellElapsed + elapsed
        if yellElapsed >= yellInterval then
            SendChatMessage(yellMessage, "YELL")
            yellElapsed = 0
        end
    end
    if isChanneling then
        chanElapsed = chanElapsed + elapsed
        if chanElapsed >= chanInterval then
            if chanID then
                SendChatMessage(chanMessage, "CHANNEL", nil, chanID)
            elseif chanName then
                local sysChan = {
                    party = "PARTY",
                    raid = "RAID",
                    guild = "GUILD",
                    say = "SAY",
                    yell = "YELL",
                }
                local chatType = sysChan[chanName:lower()]
                if chatType then
                    SendChatMessage(chanMessage, chatType)
                else
                    printMsg("Error: Invalid or unknown channel for sending message.")
                    isChanneling = false
                    return
                end
            else
                printMsg("Error: No channel set.")
                isChanneling = false
                return
            end
            chanElapsed = 0
        end
    end
end)

local function HandleCommand(msg)
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")
    cmd = cmd and cmd:lower() or ""

    if cmd == "startyell" then
        StartYelling()
    elseif cmd == "stopyell" then
        StopYelling()
    elseif cmd == "startchan" then
        StartChanneling()
    elseif cmd == "stopchan" then
        StopChanneling()
    elseif cmd == "new" then
        if rest == "" then
            printMsg("Usage: /yeller new <yell message>")
        else
            yellMessage = rest
            printMsg("Yell message updated to: " .. yellMessage)
        end
    elseif cmd == "chanmsg" then
        if rest == "" then
            printMsg("Usage: /yeller chanmsg <channel message>")
        else
            chanMessage = rest
            printMsg("Channel message updated to: " .. chanMessage)
        end
    elseif cmd == "channel" then
        if rest == "" then
            printMsg("Usage: /yeller channel <party/raid/guild/general/trade/custom>")
            return
        end

        local ch = rest:lower()
        local validSysChannels = { party=true, raid=true, guild=true, say=true, yell=true }

        if validSysChannels[ch] then
            chanName = ch
            chanID = nil
            printMsg("Channel set to system channel: " .. ch)
        else
            local id = GetJoinedChannelID(rest)
            if id then
                chanName = rest
                chanID = id
                printMsg("Channel set to '" .. chanName .. "' with ID: " .. chanID)
            else
                printMsg("Error: Channel '" .. rest .. "' not found or not joined.")
                printMsg("Use /yeller listchan to see joined channels.")
            end
        end

    elseif cmd == "yelltime" then
        local t = tonumber(rest)
        if t and t > 0 then
            yellInterval = t
            printMsg("Yell interval set to " .. yellInterval .. " seconds.")
        else
            printMsg("Usage: /yeller yelltime <seconds>")
        end
    elseif cmd == "chantime" then
        local t = tonumber(rest)
        if t and t > 0 then
            chanInterval = t
            printMsg("Channel message interval set to " .. chanInterval .. " seconds.")
        else
            printMsg("Usage: /yeller chantime <seconds>")
        end
    elseif cmd == "msg" then
        printMsg("Status:")
        printMsg("Yelling: " .. (isYelling and "ON" or "OFF") .. ", Interval: " .. yellInterval .. "s")
        printMsg("Yell message: " .. yellMessage)
        printMsg("Channel messaging: " .. (isChanneling and "ON" or "OFF") .. ", Interval: " .. chanInterval .. "s")
        printMsg("Channel: " .. (chanName or "Not set"))
        printMsg("Channel message: " .. chanMessage)
        printMsg("Use /yeller listchan to see joined channels.")
    elseif cmd == "listchan" then
        printMsg("Joined channels:")
        local foundAny = false
        for i = 1, GetNumDisplayChannels() do
            local name, _, _, _, _, _, channelID = GetChannelDisplayInfo(i)
            if name then
                printMsg(string.format("ID: %s Name: %s", channelID or "N/A", name))
                foundAny = true
            end
        end
        if not foundAny then
            printMsg("No joined channels found.")
        end

        -- Add common global channels (hardcoded)
        printMsg("Common global channels (use /yeller channel <name>):")
        local commonChannels = { "Trade", "General", "LocalDefense", "LookingForGroup", "WorldDefense" }
        for _, chan in ipairs(commonChannels) do
            printMsg("  - " .. chan)
        end
    else
        printMsg("Commands:")
        printMsg("/yeller startyell - Start yelling")
        printMsg("/yeller stopyell - Stop yelling")
        printMsg("/yeller startchan - Start sending channel messages")
        printMsg("/yeller stopchan - Stop sending channel messages")
        printMsg("/yeller new <msg> - Set yell message")
        printMsg("/yeller chanmsg <msg> - Set channel message")
        printMsg("/yeller channel <channel> - Set target channel")
        printMsg("/yeller yelltime <sec> - Set yell interval")
        printMsg("/yeller chantime <sec> - Set channel message interval")
        printMsg("/yeller msg - Show status")
        printMsg("/yeller listchan - List joined chat channels")
    end
end

SLASH_YELLER1 = "/yeller"
SlashCmdList["YELLER"] = HandleCommand
