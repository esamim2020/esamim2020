LFMYeller Addon for WoW 3.3.5a
==============================

Overview
--------
LFMYeller is a lightweight and customizable addon that helps you automate
raid/group recruitment messages by yelling and sending messages to any chat
channel you choose. Perfect for promoting your raid or group efficiently
without manual typing every time.

Features
--------
- Yell Messages: Automatically yell a custom message every configurable interval (default 20 seconds).
- Channel Messages: Send a different custom message automatically in a chosen chat channel (party, raid, guild, trade, general, custom channels).
- Independent Timers: Separate timers for yell and channel messages, adjustable via command.
- Custom Channels: Supports WoW system channels and custom public channels by name.
- Simple Slash Commands to control starting, stopping, and configuring the addon in-game.
- Status and channel list commands to help manage your settings.

Installation
------------
1. Extract the 'LFMYeller' folder into your World of Warcraft Interface/AddOns directory.
2. Enable the addon on the character selection screen.
3. Log into the game and use the /yeller commands.

Commands
--------
/yeller startyell
    Start automatic yelling
    Example: /yeller startyell

/yeller stopyell
    Stop automatic yelling
    Example: /yeller stopyell

/yeller startchan
    Start automatic sending to chosen channel
    Example: /yeller startchan

/yeller stopchan
    Stop automatic channel messages
    Example: /yeller stopchan

/yeller new <message>
    Set the yell message
    Example: /yeller new LFM raid, come join!

/yeller chanmsg <message>
    Set the channel message
    Example: /yeller chanmsg Looking for group!

/yeller channel <channel>
    Set the target channel (party, raid, guild, trade, general, or custom channel name)
    Examples:
        /yeller channel trade
        /yeller channel MyCustomChannel

/yeller yelltime <seconds>
    Set interval (seconds) for yell messages
    Example: /yeller yelltime 30

/yeller chantime <seconds>
    Set interval (seconds) for channel messages
    Example: /yeller chantime 25

/yeller msg
    Show current status and settings
    Example: /yeller msg

/yeller listchan
    List all joined chat channels
    Example: /yeller listchan

/yeller
    Show help and available commands
    Example: /yeller

Notes
-----
- For custom channels, you must be currently joined to the channel for it to work.
  Use /yeller listchan to see which channels you are joined to.
- Channel names are case-insensitive.
- Use the timers wisely to avoid spamming and possible chat restrictions.

Enjoy hassle-free group recruitment with LFMYeller!
